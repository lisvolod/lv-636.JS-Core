const express = require('express');
const app = express();

const date = new Date()

app.get('/', function(request, response) {
   response.sendFile(__dirname + '/index_12_1.html')
});

app.get('/date', function(request, response) {
    // response.set('Access-Control-Allow-Origin', '*');
    response.end(`Your vote is accepted: ${date.toUTCString()}`)
});

const PORT = process.env.PORT || 3000

const listener = app.listen(PORT, function() {
  console.log('Your app is listening on port ' + listener.address().port);
});
