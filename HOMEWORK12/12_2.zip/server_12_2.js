// Copyright 2018 Google LLC.
// SPDX-License-Identifier: Apache-2.0

const express = require('express');
const app = express();

app.get('/', function(request, response) {
  response.sendFile(__dirname + '/index_12_2.html')
});

app.get('/books.json', function(request, response) {
  response.sendFile(__dirname + '/books.json')
});

const PORT = process.env.PORT || 3000

const listener = app.listen(PORT, function() {
 console.log('Your app is listening on port ' + listener.address().port);
});

