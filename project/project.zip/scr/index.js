// Задання вихідних параметрів (title, [x], content) конфігурації модалки 
const modal = $.modal({
    title: 'Cup options',
    closable: true,
    content: `
        <div class="modal-form">
            <label for="name">Cup name:</label><br>
            <input type="text" id="name" name="name" class="modal-form-field" placeholder="Input cups name..."/><br><br>
            <label for="volume">Cup volume :</label><br>
            <input type="number" id="volume" name="volume" min="10" max="1000" class="modal-form-field" placeholder="Input cups volume (ml) between 10 & 1000"/><br><br>
            <label for="material">Cup material:</label><br>
            <select id="material" name="material" class="modal-form-field">
                <option value="Glass">Glass</option>
                <option value="Porcelain">Porcelain</option>
                <option value="Paper">Paper</option>
                <option value="Plastic">Plastic</option>
                <option value="Metal">Metal</option>
                <option value="Silicone">Silicone</option>
            </select><br><br>
            <div id= "img-prev-section">
                <img id="imgprev" src="" >
            </div>   
                <label for="file" id="label-select-img">Select image file:</label><br>
                <input type="file" id="imgfile" name="imgfile"><br><br>
            
            <button id="submitbtn" class="blue-button" onclick="myFunction()">Click me</button>
        </div> 
    `,
    width: '500px'
})

// Вибірка всіх "Volume" та обчислення "Total volume"
function countTotalVolume(){
    let volArr = document.getElementsByClassName("element-volume")
    let totalVolume = 0
    for (let i=0; i<volArr.length; i++) {
        totalVolume+= Number(volArr[i].outerText)
    }
    document.getElementById("countresult").innerHTML = `Total volume:  <b>${totalVolume} ml</b>`
}



countbtn.addEventListener('click', countTotalVolume)






